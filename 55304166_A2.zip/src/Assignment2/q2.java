package Assignment2;

import java.util.Scanner;

public class q2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the driving distance in miles: ");
		double miles = input.nextDouble(); 
		System.out.println("Enter miles per gallon: " );
		double gallon = input.nextDouble();
		System.out.println("Enter the price in $ per gallon: ");
		double price = input.nextDouble();
		System.out.println("The cost of driving is $" + (miles / gallon)* price);
		
		
	}

}

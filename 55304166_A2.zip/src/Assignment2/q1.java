package Assignment2;

import java.util.Scanner;

public class q1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter vo, v1 and t: ");
		double v0 = input.nextDouble();
		double v1 = input.nextDouble();
		double t = input.nextDouble();
		System.out.println("The average acceleration is " + (v1 - v0)/t);
		
	}

}

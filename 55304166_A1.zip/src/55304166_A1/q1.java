package Assignments01;

public class q1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("U  U   B B     C C");
		System.out.println("U  U   B   B  C   ");
		System.out.println("U  U   B B    C   ");
		System.out.println("U  U   B   B  C   ");
		System.out.println(" UU    B B     CC ");
	}

}

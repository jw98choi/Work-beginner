package Assignments01;

public class q2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("perimeter: " + (7*2+9*2));
		System.out.println("area: " + (7 * 9)); 
		
	}

}

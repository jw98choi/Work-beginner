
public class q3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double gravity = 9.81;
		double ans = (gravity * 12 * 12)/2;
		System.out.println("Distance after 12 seconds: " + ans);

	}

}
